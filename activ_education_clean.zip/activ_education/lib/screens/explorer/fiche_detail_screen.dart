// lib/screens/explorer/fiche_detail_screen.dart

import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../services/api_service.dart';
import '../../models/models.dart';

class FicheDetailScreen extends StatefulWidget {
  final FicheBase fiche;

  const FicheDetailScreen({super.key, required this.fiche});

  @override
  State<FicheDetailScreen> createState() => _FicheDetailScreenState();
}

class _FicheDetailScreenState extends State<FicheDetailScreen> {
  final _api = ApiService();
  bool _isFavori = false;
  String? _favoriId;

  // Accordéons ouverts
  final Set<String> _openSections = {'programme'};

  Color get _typeColor {
    final type = widget.fiche.typeFiche?.toLowerCase() ?? '';
    if (type.contains('serie')) return AppColors.primary;
    if (type.contains('filiere')) return const Color(0xFF10B981);
    if (type.contains('metier')) return AppColors.accent;
    return const Color(0xFF8B5CF6);
  }

  String get _typeLabel {
    final type = widget.fiche.typeFiche?.toLowerCase() ?? '';
    if (type.contains('serie')) return 'Série';
    if (type.contains('filiere')) return 'Filière';
    if (type.contains('metier')) return 'Métier';
    return 'Établissement';
  }

  Future<void> _toggleFavori() async {
    try {
      final userId = await _api.getTrackingId();
      if (userId == null) return;

      if (_isFavori && _favoriId != null) {
        await _api.supprimerFavori(_favoriId!);
        setState(() {
          _isFavori = false;
          _favoriId = null;
        });
      } else {
        final favori = await _api.ajouterFavori(FavoriRequest(
          utilisateurTrackingId: userId,
          ficheTrackingId: widget.fiche.trackingId,
        ));
        setState(() {
          _isFavori = true;
          _favoriId = favori.trackingId;
        });
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          // ── Header ──────────────────────────────────────────────────
          SliverAppBar(
            expandedHeight: 180,
            pinned: true,
            backgroundColor: _typeColor,
            leading: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.arrow_back_ios_new_rounded,
                    color: Colors.white, size: 16),
              ),
            ),
            actions: [
              IconButton(
                onPressed: _toggleFavori,
                icon: Icon(
                  _isFavori
                      ? Icons.favorite_rounded
                      : Icons.favorite_border_rounded,
                  color: Colors.white,
                ),
              ),
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.share_outlined, color: Colors.white),
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                color: _typeColor,
                padding: const EdgeInsets.fromLTRB(20, 80, 20, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        _typeLabel.toUpperCase(),
                        style: const TextStyle(
                          fontFamily: 'Nunito',
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      widget.fiche.titre,
                      style: const TextStyle(
                        fontFamily: 'Nunito',
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ── Contenu ──────────────────────────────────────────────────
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Niveau 1 : En bref ───────────────────────────────
                  _buildEnBref(),
                  const SizedBox(height: 24),

                  // ── Niveau 2 : Vidéo ─────────────────────────────────
                  if (widget.fiche.videoUrl != null &&
                      widget.fiche.videoUrl!.isNotEmpty)
                    _buildVideo(),

                  const SizedBox(height: 24),

                  // ── Niveau 3 : Pour aller plus loin ─────────────────
                  _buildPourAllerPlusLoin(),

                  const SizedBox(height: 32),

                  // ── CTA Conseiller ───────────────────────────────────
                  _buildCTAConseiller(),

                  const SizedBox(height: 80),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── NIVEAU 1 : EN BREF ───────────────────────────────────────────────────
  Widget _buildEnBref() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _typeColor.withOpacity(0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: _typeColor.withOpacity(0.15), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _typeColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'En bref',
                  style: TextStyle(
                    fontFamily: 'Nunito',
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            widget.fiche.resume,
            style: AppTextStyles.bodyLarge,
          ),
          const SizedBox(height: 12),
          // Tags matières / spécialités
          _buildTags(),
        ],
      ),
    );
  }

  Widget _buildTags() {
    List<String> tags = [];

    if (widget.fiche is FicheSerieResponse) {
      final s = widget.fiche as FicheSerieResponse;
      if (s.matieresPrincipales != null) {
        tags = s.matieresPrincipales!.split(',').map((e) => e.trim()).toList();
      }
    } else if (widget.fiche is FicheFiliereResponse) {
      final f = widget.fiche as FicheFiliereResponse;
      if (f.duree != null) tags.add(f.duree!);
      if (f.niveauRequis != null) tags.add(f.niveauRequis!);
    } else if (widget.fiche is FicheMetierResponse) {
      final m = widget.fiche as FicheMetierResponse;
      if (m.secteur != null) tags.add(m.secteur!);
    }

    if (tags.isEmpty) return const SizedBox.shrink();

    return Wrap(
      spacing: 8,
      runSpacing: 6,
      children: tags
          .take(4)
          .map((tag) => Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                      color: _typeColor.withOpacity(0.3)),
                ),
                child: Text(
                  tag,
                  style: TextStyle(
                    fontFamily: 'Nunito',
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: _typeColor,
                  ),
                ),
              ))
          .toList(),
    );
  }

  // ── NIVEAU 2 : VIDÉO ─────────────────────────────────────────────────────
  Widget _buildVideo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Comprendre en vidéo', style: AppTextStyles.headingMedium),
        const SizedBox(height: 12),
        GestureDetector(
          onTap: () {
            // TODO: ouvrir lecteur vidéo / YouTube
          },
          child: Container(
            height: 190,
            decoration: BoxDecoration(
              color: AppColors.textDark,
              borderRadius: BorderRadius.circular(14),
              image: widget.fiche.imageUrl != null
                  ? DecorationImage(
                      image: NetworkImage(widget.fiche.imageUrl!),
                      fit: BoxFit.cover,
                      colorFilter: ColorFilter.mode(
                          Colors.black.withOpacity(0.4),
                          BlendMode.darken),
                    )
                  : null,
            ),
            child: Stack(
              children: [
                // Play button
                Center(
                  child: Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: AppColors.accent,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.accent.withOpacity(0.4),
                          blurRadius: 16,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: const Icon(Icons.play_arrow_rounded,
                        color: Colors.white, size: 30),
                  ),
                ),
                // Durée
                Positioned(
                  bottom: 12,
                  right: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text(
                      '3 min 24',
                      style: TextStyle(
                        fontFamily: 'Nunito',
                        fontSize: 11,
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Tout savoir sur ${widget.fiche.titre}',
          style: AppTextStyles.bodyMedium
              .copyWith(color: AppColors.textMedium),
        ),
      ],
    );
  }

  // ── NIVEAU 3 : POUR ALLER PLUS LOIN ──────────────────────────────────────
  Widget _buildPourAllerPlusLoin() {
    // Sections selon le type de fiche
    List<_Section> sections = _getSections();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Pour aller plus loin', style: AppTextStyles.headingMedium),
        const SizedBox(height: 12),
        ...sections.map((s) => _buildAccordion(s)),
      ],
    );
  }

  List<_Section> _getSections() {
    if (widget.fiche is FicheSerieResponse) {
      final s = widget.fiche as FicheSerieResponse;
      return [
        _Section('Programme détaillé', s.matieresPrincipales ?? ''),
        _Section('Profil idéal', 'Élève curieux, rigoureux, passionné par les matières de cette série.'),
        _Section('Débouchés', s.debouches ?? 'Plusieurs filières universitaires accessibles.'),
        _Section('Témoignages', 'Des anciens élèves partagent leur expérience dans cette série.'),
      ];
    } else if (widget.fiche is FicheFiliereResponse) {
      final f = widget.fiche as FicheFiliereResponse;
      return [
        _Section('Conditions d\'admission', f.conditionsAdmission ?? ''),
        _Section('Programme pédagogique', f.programme ?? ''),
        _Section('Débouchés professionnels', f.debouchesMetiers ?? ''),
      ];
    } else if (widget.fiche is FicheMetierResponse) {
      final m = widget.fiche as FicheMetierResponse;
      return [
        _Section('Missions principales', m.missions ?? ''),
        _Section('Compétences requises', m.competences ?? ''),
        _Section('Débouchés au Togo', m.debouchesTogo ?? ''),
        _Section('Fourchette de salaire', m.fourchetteSalaire ?? ''),
      ];
    } else if (widget.fiche is FicheEtablissementResponse) {
      final e = widget.fiche as FicheEtablissementResponse;
      return [
        _Section('Localisation', '${e.adresse ?? ''}\n${e.ville ?? ''}, ${e.region ?? ''}'),
        _Section('Contacts', e.contacts ?? ''),
        _Section('Site web', e.siteWeb ?? ''),
      ];
    }
    return [];
  }

  Widget _buildAccordion(_Section section) {
    final isOpen = _openSections.contains(section.titre);
    final hasContent = section.contenu.trim().isNotEmpty;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 6,
          ),
        ],
      ),
      child: Column(
        children: [
          GestureDetector(
            onTap: () {
              if (!hasContent) return;
              setState(() {
                if (isOpen) {
                  _openSections.remove(section.titre);
                } else {
                  _openSections.add(section.titre);
                }
              });
            },
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      section.titre,
                      style: AppTextStyles.label,
                    ),
                  ),
                  if (hasContent)
                    AnimatedRotation(
                      turns: isOpen ? 0.5 : 0,
                      duration: const Duration(milliseconds: 200),
                      child: Icon(
                        Icons.keyboard_arrow_down_rounded,
                        color: AppColors.textMedium,
                        size: 20,
                      ),
                    )
                  else
                    const Icon(Icons.chevron_right_rounded,
                        color: AppColors.textLight, size: 20),
                ],
              ),
            ),
          ),
          if (isOpen && hasContent)
            Container(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Text(
                section.contenu,
                style: AppTextStyles.bodyMedium,
              ),
            ),
        ],
      ),
    );
  }

  // ── CTA CONSEILLER ───────────────────────────────────────────────────────
  Widget _buildCTAConseiller() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: AppColors.primary.withOpacity(0.15)),
      ),
      child: Row(
        children: [
          const Icon(Icons.support_agent_rounded,
              color: AppColors.primary, size: 28),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Une question sur cette fiche ?',
                  style: AppTextStyles.label,
                ),
                Text(
                  'Pose ta question à un conseiller',
                  style: AppTextStyles.caption,
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              // TODO: naviguer vers Messages avec contexte
            },
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text(
                'Contacter',
                style: TextStyle(
                  fontFamily: 'Nunito',
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Section {
  final String titre;
  final String contenu;
  const _Section(this.titre, this.contenu);
}
