import 'package:flutter/material.dart';
import '../widgets/bottom_nav.dart';
import 'home/dashboard_bachelier.dart';
import 'explorer/explorer_screen.dart';

class MainScaffold extends StatefulWidget {
  const MainScaffold({super.key});

  @override
  State<MainScaffold> createState() => _MainScaffoldState();
}

class _MainScaffoldState extends State<MainScaffold> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const DashboardBachelier(),
    const ExplorerScreen(),
    const _PlaceholderScreen(label: 'Diagnostic', icon: Icons.quiz_rounded),
    const _PlaceholderScreen(label: 'Messages', icon: Icons.chat_bubble_rounded),
    const _PlaceholderScreen(label: 'Profil', icon: Icons.person_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: AppBottomNav(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
      ),
    );
  }
}

class _PlaceholderScreen extends StatelessWidget {
  final String label;
  final IconData icon;
  const _PlaceholderScreen({required this.label, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F5F9),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 48, color: const Color(0xFF3D35D9)),
            const SizedBox(height: 12),
            Text(label, style: const TextStyle(
              fontFamily: 'Nunito', fontSize: 20,
              fontWeight: FontWeight.w700, color: Color(0xFF1A1A2E),
            )),
            const SizedBox(height: 6),
            Text('À venir...', style: TextStyle(
              fontFamily: 'Nunito', fontSize: 14, color: Colors.grey[500],
            )),
          ],
        ),
      ),
    );
  }
}
