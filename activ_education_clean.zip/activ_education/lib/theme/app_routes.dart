class AppRoutes {
  static const String splash = '/';
  static const String onboarding = '/onboarding';
  static const String profileSetup = '/profile-setup';
  static const String register = '/register';
  static const String registerPreferences = '/register-preferences';
  static const String login = '/login';
  static const String forgotPassword = '/forgot-password';
  static const String otp = '/otp';
  static const String home = '/home';
  static const String dashboard = '/dashboard';
  static const String profile = '/profile';
  static const String explorer = '/explorer';
  static const String diagnostic = '/diagnostic';
  static const String messages = '/messages';
  static const String notifications = '/notifications';
  static const String rdv = '/rdv';
}
